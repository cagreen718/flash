#CarnellGreenfield
#9/18/2020
#This is the ipassignment
print("Welcome")
#the hrs should be 3 times the credit hr
hour_credit = int(input("Enter the number of credit hours you are taking:"))
hour_spent = (hour_credit*3)
#now I have to print my statement
print("You should be studying",hour_spent,"hours per week.")
